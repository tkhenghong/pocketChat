package com.pocketchat.models;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
