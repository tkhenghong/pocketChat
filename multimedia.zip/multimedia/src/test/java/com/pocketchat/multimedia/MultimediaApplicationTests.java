package com.pocketchat.multimedia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultimediaApplicationTests {

	@Test
	void contextLoads() {
	}

}
