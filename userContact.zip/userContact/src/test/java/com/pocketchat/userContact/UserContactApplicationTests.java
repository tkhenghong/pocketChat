package com.pocketchat.userContact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserContactApplicationTests {

	@Test
	void contextLoads() {
	}

}
