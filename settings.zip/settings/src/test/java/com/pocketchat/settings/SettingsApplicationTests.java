package com.pocketchat.settings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SettingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
