package com.pocketchat.unreadMessage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnreadMessageApplicationTests {

	@Test
	void contextLoads() {
	}

}
