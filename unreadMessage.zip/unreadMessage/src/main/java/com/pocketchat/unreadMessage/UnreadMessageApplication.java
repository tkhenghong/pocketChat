package com.pocketchat.unreadMessage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnreadMessageApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnreadMessageApplication.class, args);
	}

}
